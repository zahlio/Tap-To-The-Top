//
//  IOSNativePopUpsManager.h
//  Unity-iPhone
//
//  Created by Osipov Stanislav on 5/31/14.
//
//

#import <Foundation/Foundation.h>
#import "RatePopUPDelegate.h"
#import "PopUPDelegate.h"
#import "ISNDataConvertor.h"

@interface IOSNativePopUpsManager : NSObject

+ (void) unregisterAllertView;

@end
