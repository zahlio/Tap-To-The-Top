//
//  RatePopUPDelegate.h
//
//  Created by Osipov Stanislav on 1/12/13.
//
//

#import <Foundation/Foundation.h>

@interface PopUPDelegate : NSObject

@end
