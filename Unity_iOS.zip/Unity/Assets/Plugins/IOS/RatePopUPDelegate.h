//
//  RatePopUPDelegate.h
//
//  Created by Osipov Stanislav on 1/12/13.
//
//

#import <Foundation/Foundation.h>

@interface RatePopUPDelegate : NSObject

+ (void)rateApp;
@end
