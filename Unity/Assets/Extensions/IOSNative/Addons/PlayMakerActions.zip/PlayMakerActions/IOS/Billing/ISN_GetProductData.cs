using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Get product ID's data. IOSBillingInitAction has to be called first")]
	public class ISN_GetProductData : FsmStateAction {
		
		
		[RequiredField]
		public FsmString productIdentifier;
		
		[ActionSection("Result")]
		
		[UIHint(UIHint.Variable)]
		public FsmString title;
		
		[UIHint(UIHint.Variable)]
		public FsmString description;
		
		[UIHint(UIHint.Variable)]
		public FsmString price;
		
		[UIHint(UIHint.Variable)]
		public FsmString currencySymbol;
		
		
		[UIHint(UIHint.Variable)]
		public FsmString currencyCode;
		
		[UIHint(UIHint.Variable)]
		public FsmString formattedPrice;
		
		public FsmEvent productFoundEvent;
		public FsmEvent productNotFoundEvent;


		public override void Reset() {
			productIdentifier = null;
			title = null;
			description = null;
			price = null;
			currencySymbol = null;
			currencyCode = null;
			formattedPrice = null;
			productFoundEvent = null;
			productNotFoundEvent = null;
		}


		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);
			
		}

		private void OnBillingInit() {

			ProductTemplate tpl = IOSInAppPurchaseManager.instance.GetProductById(productIdentifier.Value);
			if(tpl != null) {
				title.Value 			= tpl.title;
				description.Value 		= tpl.description;
				price.Value				= tpl.price;
				currencySymbol.Value 	= tpl.currencySymbol;
				currencyCode.Value 	    = tpl.currencyCode;
				formattedPrice.Value 	= tpl.localizedPrice;
				Fsm.Event(productFoundEvent);
			} else {
				Fsm.Event(productNotFoundEvent);
			}
			
			
			Finish ();
		}
		
	}
}




